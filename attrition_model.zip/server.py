# Importing flask module in the project is mandatory
# An object of Flask class is our WSGI application.
from flask import Flask,request
import pickle
import sklearn
from flask_cors import CORS
# Flask constructor takes the name of
# current module (__name__) as argument.
app = Flask(__name__)
CORS(app, resources={r"*": {"origin": "*"}})
# api_conf = {"origins": ["http://localhost:5000"], "method": ["GET"]}
# cors = CORS(app, resources={r"*": {"origin": "*"}})


# The route() function of the Flask class is a decorator,
# which tells the application which URL should call
# the associated function.
@app.route('/')
# ‘/’ URL is bound with hello_world() function.
def hello_world():
	return 'Hello World'

@app.route("/predictCancer",methods=["POST","GET"])
def predictCancer():
    model=pickle.load(open("CancerModel.p","rb"))
    # n=[17.99, 10.38, 122.8, 1001.0, 0.1184, 0.2776, 0.3001, 0.1471, 0.2419, 0.07871, 1.095, 0.9053, 8.589, 153.4, 0.006399, 0.04904, 0.05373, 0.01587, 0.03003, 0.006193, 25.38, 17.33, 184.6, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.1189]
    prediction=""
    prediction_input=[]
    if request.method=="POST":
	    prediction_input=[float(i) for i in request.form["data"].split(",")]
	    prediction=str(model.predict([prediction_input])[0])
	    print(prediction)
	    
    # print(prediction)
    return {"prediction":prediction}

@app.route("/predictCustomerSegmentation",methods=["POST","GET"])
def predictCustomerSegmentation():
    model=pickle.load(open("Customer_segmantion_model.p","rb"))
    # n=[17.99, 10.38, 122.8, 1001.0, 0.1184, 0.2776, 0.3001, 0.1471, 0.2419, 0.07871, 1.095, 0.9053, 8.589, 153.4, 0.006399, 0.04904, 0.05373, 0.01587, 0.03003, 0.006193, 25.38, 17.33, 184.6, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.1189]
    prediction=""
    prediction_input=[]
    if request.method=="POST":
	    prediction_input=[float(i) for i in request.form["data"].split(",")]
	    prediction=str(model.predict([prediction_input])[0])
	    print(prediction)
	    
    # print(prediction)
    return {"prediction":prediction}

@app.route("/predictAttrition",methods=["POST","GET"])
def predictAttrition():
    model=pickle.load(open("attrition_model.p","rb"))
    # n=[17.99, 10.38, 122.8, 1001.0, 0.1184, 0.2776, 0.3001, 0.1471, 0.2419, 0.07871, 1.095, 0.9053, 8.589, 153.4, 0.006399, 0.04904, 0.05373, 0.01587, 0.03003, 0.006193, 25.38, 17.33, 184.6, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.1189]
    prediction=""
    prediction_input=[]
    if request.method=="POST":
	    prediction_input=[float(i) for i in request.form["data"].split(",")]
	    prediction=str(model.predict([prediction_input])[0])
	    print(prediction)
	    
    # print(prediction)
    return {"prediction":prediction}

@app.route("/predictCarPrice",methods=["POST","GET"])
def predictCarPrice():
    model=pickle.load(open("car_price_model.p","rb"))
    # n=[17.99, 10.38, 122.8, 1001.0, 0.1184, 0.2776, 0.3001, 0.1471, 0.2419, 0.07871, 1.095, 0.9053, 8.589, 153.4, 0.006399, 0.04904, 0.05373, 0.01587, 0.03003, 0.006193, 25.38, 17.33, 184.6, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.1189]
    prediction=""
    prediction_input=[]
    if request.method=="POST":
	    prediction_input=[float(i) for i in request.form["data"].split(",")]
	    prediction=str(model.predict([prediction_input])[0])
	    print(prediction)
	    
    # print(prediction)
    return {"prediction":prediction}
@app.route("/predict_e_signing",methods=["POST","GET"])
def predict_e_signing():
    model=pickle.load(open("E_signing.p","rb"))
    # n=[17.99, 10.38, 122.8, 1001.0, 0.1184, 0.2776, 0.3001, 0.1471, 0.2419, 0.07871, 1.095, 0.9053, 8.589, 153.4, 0.006399, 0.04904, 0.05373, 0.01587, 0.03003, 0.006193, 25.38, 17.33, 184.6, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.1189]
    prediction=""
    prediction_input=[]
    if request.method=="POST":
	    prediction_input=[float(i) for i in request.form["data"].split(",")]
	    prediction=str(model.predict([prediction_input])[0])
	    print(prediction)
	    
    # print(prediction)
    return {"prediction":prediction}

@app.route("/predict_Medical_Insurance",methods=["POST","GET"])
def predict_Medical_Insurance():
    model=pickle.load(open("Medical_Insurance.p","rb"))
    # n=[17.99, 10.38, 122.8, 1001.0, 0.1184, 0.2776, 0.3001, 0.1471, 0.2419, 0.07871, 1.095, 0.9053, 8.589, 153.4, 0.006399, 0.04904, 0.05373, 0.01587, 0.03003, 0.006193, 25.38, 17.33, 184.6, 2019.0, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.1189]
    prediction=""
    prediction_input=[]
    if request.method=="POST":
	    prediction_input=[float(i) for i in request.form["data"].split(",")]
	    prediction=str(model.predict([prediction_input])[0])
	    print(prediction)
	    
    # print(prediction)
    return {"prediction":prediction}

# main driver function
if __name__ == '__main__':

	# run() method of Flask class runs the application
	# on the local development server.
	app.run()
